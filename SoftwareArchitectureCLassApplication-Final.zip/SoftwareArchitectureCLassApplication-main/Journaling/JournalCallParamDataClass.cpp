#include "JournalCallParamDataClass.h"
#include "JournalingInternal.h"
#include "JournalFile.h"
#include "..\Core\GuidObject.h"

using namespace Journal;

JournalCallParamDataClass::JournalCallParamDataClass(std::string paramName, ParameterMetaType paramType,
    GuidObject* classObject, std::string className) :
    JournalCallParamData(paramName, paramType, JournalCallParamData::ParameterBasicType::STRING), m_classObject(classObject),
    m_paramName(paramName), m_className(className)
{

}

void JournalCallParamDataClass::Journal()
{


    if (this->m_paramType == JournalCallParamData::ParameterMetaType::INPUT)
    {
        //TODO only handled the nullptr case
        if (this->m_classObject == nullptr)
        {
            std::string journalString = "nullptr";
            GetActiveJournalFile()->WriteToFile(journalString);
        }
        else
        {
            throw std::exception("NIY ");
        }
    }
    else if (this->m_paramType == JournalCallParamData::ParameterMetaType::OUTPUT)
    {
        throw std::exception("NIY ");
    }
    else // RETURN
    {
        std::string paramName;

        if (!InGuidToParamMap(this->m_classObject->GetGuid()))
        {
            paramName = GenerateVariableName(m_paramName);
            AddGuidToParamMap(this->m_classObject->GetGuid(), paramName);

            std::string journalString = m_className + " * " + paramName + " = ";
            GetActiveJournalFile()->WriteToFile(journalString);
        }
        else
        {
            bool finder = false;
            paramName = GetGuidToParam(this->m_classObject->GetGuid(), finder);
            //from a query method called multiple times
            std::string journalString ;
            if (finder)
            {
                journalString = paramName + " = ";
            }
            else
            {
                std::string temp = "<UNKNOWN>";
                journalString = temp + " = ";
            }
            GetActiveJournalFile()->WriteToFile(journalString);

        }

// create a client
var client = HttpClient.newHttpClient();

// create a request
var request = HttpRequest.newBuilder(
       URI.create("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY"))
   .header("accept", "application/json")
   .build();

// use the client to send the request
var respon = client.send(request, new JsonBodyHandler<>(APOD.class));

// the respon:
System.out.println(respon.body().get().title);


    }

}