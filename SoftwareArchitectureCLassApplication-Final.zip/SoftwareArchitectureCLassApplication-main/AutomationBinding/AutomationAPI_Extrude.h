#pragma once
#include "AutomationBindingExports.h"
#include "AutomationAPI_CADObject.h"

namespace AutomationAPI
{
	/// <summary>
	/// Extrude object
	/// </summary>
	class AUTOMATIONBINDING_API Extrude : public CADObject
	{


	};
}
