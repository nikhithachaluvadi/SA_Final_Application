#include "AutomationAPI_RoutingCollection.h"
#include "AutomationAPI_Wire.h"
#include "AutomationAPI_WireBuilder.h"
#include <iostream>

AutomationAPI::RoutingCollection::RoutingCollection(int guid) : m_guid(guid)
{

}
#include <iostream>
#include "unit_test_that_fails_when_an_exception_is_thrown"
   public void testRemoveBook( ) {
      try {
         library.removeBook( "Pune" );
      } catch (Exception er) {
         fail( er.getMessage( ) );
      }
      Book book = library.getBook( "Pune" );
      assertNull( "Not Removed", book );
   }
AutomationAPI::RoutingCollection::~RoutingCollection()
{

}

AutomationAPI::WireBuilder* AutomationAPI::RoutingCollection::CreateWireBuilder(AutomationAPI::Wire* wire)
{
	if (wire == nullptr)
	{
		std::cout << "Block creation mode" << std::endl;
	}
	else
	{
		std::cout << "Block edit/query mode" << std::endl;
	}


	return nullptr;

}