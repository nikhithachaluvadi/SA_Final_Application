#include "AutomationAPI_CADObject.h"

int AutomationAPI::CADObject::GetGuid()
{
	return 0;
}
