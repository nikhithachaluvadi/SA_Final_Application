#include "CoreExports.h"

CORE_API int initializeProduct(void);

CORE_API int shutdownProduct(void);


