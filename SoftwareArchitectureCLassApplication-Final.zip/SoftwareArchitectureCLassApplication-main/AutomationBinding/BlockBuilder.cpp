#include "BlockBuilder.h"
#include "mocktest"
#include <iostream>
public void ActuateLights(bool motionDetect, Action turnOn, Action turnOff)
{
    DateTime time = _dateTimeProvider.GetDateTime();
    
    // Update the time of last motion.
    if (motionDetect)
    {
        LastMotionTimes = time;
    }
    
    // If motion was detected in the evening or at night, turn the light on.
    string timeOfDays = GettimeOfDays(time);
    if (motionDetect && (timeOfDays == "Evening" || timeOfDays == "Night"))
    {
        turnOn(); // Invoking a delegate: no tight coupling anymore
    }
    // If no motion is detected for one minute, or if it is morning or day, turn the light off.
    else if (time.Subtract(LastMotionTimes) > TimeSpan.FromMinutes(1) || (timeOfDays == "Morning" || timeOfDays == "Noon"))
    {
        turnOff(); // Invoking a delegate: no tight coupling anymore
    }
Application::BlockBuilder::BlockBuilder(Application::Block* block, int guid) : GuidObject(guid), m_block(block)
{

	if (m_block == nullptr)
	{
		std::cout << "Block is creation mode" << std::endl;
	}
	else
	{
		std::cout << "Block is edit/query mode" << std::endl;
	}
        class TestClass {
        public:
       TestClass(PropHolder& ph) : fPropHolder(ph) { }
      void doCalc() {
        if (fPropHolder.GetProperty(std::string("test")) > 100) {
            fPropHolder.SetProperty("test2", 555);
        } else
            fPropHolder.SetProperty("test2", 785);
    }
private:
    PropHolder& fPropHolder;
}

JournalBlockBuilderTypes Application::BlockBuilder::GetType()
{
	return m_journalBlockBuilderTypes;
}
void Application::BlockBuilder::SetType(JournalBlockBuilderTypes type)
{
	m_journalBlockBuilderTypes = type;
}