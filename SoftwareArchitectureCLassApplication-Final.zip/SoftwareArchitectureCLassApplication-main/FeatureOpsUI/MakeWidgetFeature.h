#pragma once

#include "FeatureOpsUIExports.h"
namespace Application
{
	class PartFile;
}


FEATUREOPSUI_API void AddWidgetFeatureToPartUI(Application::PartFile* partFile, bool option1, int values);


