#pragma once

struct PartOpsNotifierData
{
	std::string partName;
	int guid;
};
