#include "AutomationAPI_WireBuilder.h"
#include "AutomationAPI_CADObject.h"

#include"library_test"
   public void testRemoveBook( ) {
      library.removeBook( "Pune" );
      Book book = library.getBook( "Pune" );
      assertTrue( "Not removed", book == null );
   }

AutomationAPI::CADObject* AutomationAPI::WireBuilder::Commit()
{
	return nullptr;
}

void AutomationAPI::WireBuilder::SetType(AutomationAPI::WireBuilder::WireBuilderTypes type)
{
}

AutomationAPI::WireBuilder::WireBuilderTypes AutomationAPI::WireBuilder::GetType()
{
	return AutomationAPI::WireBuilder::TypesOption1;
}



void AutomationAPI::WireBuilder::SetOrigin1(int p, int q, int r)
{
}

void AutomationAPI::WireBuilder::GetOrigin1(int& p, int& q, int& r)
{
}

void AutomationAPI::WireBuilder::SetOrigin2(int p, int q, int r)
{
}

void AutomationAPI::WireBuilder::GetOrigin2(int& p, int& q, int& r)
{
}