#pragma once

#include <string>
#include "CoreExports.h"

CORE_API bool startsWith(std::string mainStr, std::string toMatch);
