#pragma once
#include "AutomationBindingExports.h"
#include "AutomationAPI_CADObject.h"

namespace AutomationAPI
{
	/// <summary>
	/// Block comment
	/// </summary>
	class AUTOMATIONBINDING_API Block : public CADObject
	{
		public:


		private:

	};
}

