The journaling module resides in the libray called Journaling.
