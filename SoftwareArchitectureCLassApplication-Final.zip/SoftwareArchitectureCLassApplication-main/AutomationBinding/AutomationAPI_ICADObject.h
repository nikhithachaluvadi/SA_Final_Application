#pragma once
#include "AutomationBindingExports.h"
namespace AutomationAPI
{
	/// <summary>
	/// ICADObject comment
	/// </summary>
	class AUTOMATIONBINDING_API ICADObject
	{

		virtual int GetGuid() = 0;


	};
}