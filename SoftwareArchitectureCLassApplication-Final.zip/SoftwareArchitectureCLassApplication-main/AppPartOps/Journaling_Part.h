#pragma once
#include "AppPartOpsExports.h"
#include "PartOps.h"

extern APPPARTOPS_API void Journaling_Part_Save(Application::PartFile* partFile);

extern APPPARTOPS_API void Journaling_Part_MakeWidgetFeature(Application::PartFile* partFile, bool option1, int values);


