#pragma once
#include "AutomationBindingExports.h"
#include "AutomationAPI_CADObject.h"

namespace AutomationAPI
{
	/// <summary>
	/// Wire comment
	/// </summary>
	class AUTOMATIONBINDING_API Wire : public CADObject
	{
		public:


		private:

	};
}

